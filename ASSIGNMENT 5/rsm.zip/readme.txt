RSM and RSM Wizard
Installation Complete

The RSM demo is fully functional and will process up
to 10 source files.  The RSM Wizard is fully operational
for the shareware version of RSM and when RSM licenses
have active software maintenance.

The RSM Wizard will commence upon the completion of the
install script.

Ordering Information
--------------------
Please contact M Squared Technologies for latest
products and pricing.

Contact Information
-------------------
Email: sales@mSquaredTechnologies.com
Web Site: http://mSquaredTechnologies.com
Phone/Fax: 1-877-657-6448

M Squared Technologies
(C) 1996-2009
